// 실제 사이트에서는 아래 타이머 대신 준비 중인 작업의 진행률을 전달합니다.
document.getElementById('replay').addEventListener('click', () => location.reload());

const loader = window.MainIntroLoading;
if (loader) {
  const duration = matchMedia('(prefers-reduced-motion: reduce)').matches ? 1200 : 4600;
  const startedAt = performance.now();

  function advance(now) {
    const fraction = (now - startedAt) / duration;
    if (fraction >= 1) {
      loader.finish();
      return;
    }
    loader.update(Math.floor(fraction * 100));
    requestAnimationFrame(advance);
  }

  requestAnimationFrame(advance);
}
